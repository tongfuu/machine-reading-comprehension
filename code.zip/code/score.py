import re
import json


def evaluate(ans_pred, ans_true):
    """ Evaluate the average f1 score and Exact Match score for given answers.
        For each question, take the highest scores over all ground truth answers.
        Input: ans_pred: predicted answers for a set of questions (list of strings)
               ans_true: true answers (list of list of strings, empty list if
                         is_impossible==True for an unanswerable question)
        Output: EM_score (float)
                f1_score (float)
    """
    # assert(len(ans_pred) == len(ans_true), "The lengths of ans_pred and ans_true must be the same.")
    n = len(ans_pred)

    EM_sum, F1_sum = 0, 0
    for i, ans in enumerate(ans_pred):
        EM_max, f1_max = 0, 0
        if len(ans_true[i]) == 0:
            EM_max = EM(ans, "")
            f1_max = f1(ans, "")
        else:
            for one_true in ans_true[i]:
                EM_max = max(EM(ans, one_true), EM_max)
                f1_max = max(f1(ans, one_true), f1_max)
        EM_sum += EM_max
        F1_sum += f1_max

    return EM_sum/n, F1_sum/n



def f1(ans_pred, ans_true):
    """ Calculate the f1 score.
        Input: ans_pred: predicted answer for a question (string)
               ans_true: true answer (string)
        Output: f1_score (float)
    """
    pred_bag = normalize_text(ans_pred).split()
    true_bag = normalize_text(ans_true).split()
    if len(pred_bag) == 0 or len(true_bag) == 0:
        return int(pred_bag == true_bag)

    overlap = set(pred_bag) & set(true_bag)
    if len(overlap) == 0:
        return 0

    precision = len(overlap) / len(pred_bag)
    recall = len(overlap) / len(true_bag)
    f1_score = (2 * precision * recall) / (precision + recall)

    return f1_score



def EM(ans_pred, ans_true):
    """ Calculate the Exact Match score, 1 if exactly match, 0 otherwise.
        Input: ans_pred: predicted answer for a question (string)
               ans_true: true answer (string)
        Output: EM_score (integer)
    """
    return int(normalize_text(ans_pred) == normalize_text(ans_true))



def normalize_text(text):
    """ Lower text and remove punctuation, articles and extra whitespace.
        Input: text (string)
        Output: normalized_text (string)
    """
    # remove punctuations
    text = re.sub(r'[^0-9A-Za-z\u4e00-\u9fa5]', ' ', text)
    # remove articles
    text = re.sub(r'(^|\s)(a|an|the)($|\s)', ' ', text)
    # lower text
    text = text.lower()
    # remove extra white spaces
    text = " ".join(text.split())

    return text



def main():
    with open("dev-v2.0.json", 'r') as f:
        dataset_json = json.load(f)
        dataset = dataset_json['data']
    with open("dev-evaluate.txt", 'r') as f:
        preds = json.load(f)

    ans_pred, ans_true = [], []
    for article in dataset:
        for p in article['paragraphs']:
            for qa in p['qas']:
                qid = qa['id']
                if qid not in preds:
                    print('Missing prediction for %s' % qid)
                else:
                    ans_pred.append(preds[qid])
                    a_true = [a['text'] for a in qa['answers']]
                    if not a_true:
                        # For unanswerable questions, only correct answer is empty string
                        a_true = ['']
                    ans_true.append(a_true)

    EM_score, f1_score = evaluate(ans_pred, ans_true)
    print(EM_score, f1_score)



if __name__ == '__main__':
    main()
